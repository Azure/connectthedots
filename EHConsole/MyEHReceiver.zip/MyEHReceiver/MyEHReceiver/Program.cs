﻿using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MyEHReceiver
{
    class Program
    {
        static void Main(string[] args)
        {
            var partitionCount = 8;
            var serviceNamespace = "olivier-ns";
            //var hubName = "olivieralerts";
            //var receiverKeyName = "WebSite";
            //var receiverKey = "bv94TQKs7RKBjeKMWUy0jXHe/nVsuKq6+UpX5kStoeY=";
            var hubName = "olivierdevices";
            var receiverKeyName = "WebSite";
            var receiverKey = "GFpLf/iDCQyc8NTLa2NGr8bf2UW5Gv7vE+AE1LfzeQA=";
            Console.WriteLine("Starting temperature processor with {0} partitions.", partitionCount);

            CancellationTokenSource cts = new CancellationTokenSource();

            for (int i = 0; i <= partitionCount - 1; i++)
            {
                Task.Factory.StartNew((state) =>
                {
                    Console.WriteLine("Starting worker to process partition: {0}", state);

                    var factory = MessagingFactory.Create(ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, ""), new MessagingFactorySettings()
                    {
                        TokenProvider = TokenProvider.CreateSharedAccessSignatureTokenProvider(receiverKeyName, receiverKey),
                        TransportType = TransportType.Amqp
                    });

                    var receiver = factory.CreateEventHubClient(hubName)
                        .GetDefaultConsumerGroup()
                        .CreateReceiver(state.ToString(), DateTime.UtcNow);

                    while (true)
                    {
                        // Receive could fail, I would need a retry policy etc...
                        var messages = receiver.Receive(10);
                        foreach (var message in messages)
                        {
                            //var eventBody = Newtonsoft.Json.JsonConvert.DeserializeObject<TemperatureEvent>(Encoding.Default.GetString(message.GetBytes()));
                            //Console.WriteLine("{0} [{1}] Temperature: {2}", DateTime.Now, message.PartitionKey, eventBody.Temperature);
                            Console.WriteLine(message.PartitionKey + " sent message:" + Encoding.Default.GetString(message.GetBytes()));
                        }

                        if (cts.IsCancellationRequested)
                        {
                            Console.WriteLine("Stopping: {0}", state);
                            receiver.Close();
                        }
                    }
                }, i);
            }

            Console.ReadLine();
            cts.Cancel();
            Console.WriteLine("Wait for all receivers to close and then press ENTER.");
            Console.ReadLine();


        }
    }
}
